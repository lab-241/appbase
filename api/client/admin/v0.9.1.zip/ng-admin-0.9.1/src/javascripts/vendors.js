global.rangy = require('../../node_modules/rangy/lib/rangy-core');
global.rangy = require('../../node_modules/rangy/lib/rangy-selectionsaverestore');
global.numeral = require('numeral');

require('angular-ui-router');
require('../../node_modules/textangular/dist/textAngular-sanitize');
require('angular-ui-codemirror');
require('nginflection');
require('textangular');
require('ui-select');

require('../../node_modules/angular-numeraljs/dist/angular-numeraljs');
require('angular-bootstrap/ui-bootstrap');
require('angular-bootstrap/ui-bootstrap-tpls');
require('../../node_modules/ng-file-upload/dist/ng-file-upload');

global._ = require('underscore');
